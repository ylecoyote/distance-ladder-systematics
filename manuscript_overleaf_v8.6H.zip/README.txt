================================================================================
Overleaf Package - Forensic Analysis of Distance Ladder Systematics
================================================================================

PACKAGE CONTENTS
================================================================================

Core Files:
  - manuscript.tex        Main manuscript (LaTeX source)
  - references.bib        Complete bibliography
  - aastex701.cls         AASTeX 7.01 document class
  - README.txt            This file

Subdirectories:
  - tables/               8 LaTeX table files
  - figures/              All figures (PDF and PNG formats)

================================================================================
COMPILATION INSTRUCTIONS
================================================================================

Method 1: Overleaf (Recommended)
--------------------------------------------------------------------------------
1. Go to https://www.overleaf.com
2. Click "New Project" → "Upload Project"
3. Select the entire ZIP file
4. Overleaf will extract and set up the project automatically

Configuration:
  - Main document: manuscript.tex (should auto-detect)
  - Compiler: pdfLaTeX (should be default)
  - Click "Recompile"

Post-upload fix (optional, for proper σ rendering):
  Add this line after line 12 in manuscript.tex:
  \usepackage{lmodern}

Expected output: ~35-40 page PDF with all figures and tables

Method 2: Local Compilation
--------------------------------------------------------------------------------
Requirements:
  - Full TeX Live or MiKTeX distribution
  - BibTeX support
  - pdfLaTeX compiler

Commands:
  pdflatex manuscript
  bibtex manuscript
  pdflatex manuscript
  pdflatex manuscript

Note: The double pdflatex run after bibtex is required for cross-references.

================================================================================
KEY BASELINE VALUES (Scenario A + Prior 1)
================================================================================

Citation: Riess+ 2022 (R22) SH0ES baseline
  H₀ = 73.04 ± 1.04 km/s/Mpc

Corrected Values:
  Stage 4: H₀ = 70.54 ± 1.65 km/s/Mpc (after period correction)
  Stage 5: H₀ = 69.54 ± 1.89 km/s/Mpc (final with systematics)

Systematic Budget:
  SH0ES claimed:  σ_sys = 1.04 km/s/Mpc
  Our assessment: σ_sys = 1.71 km/s/Mpc (1.6× factor with correlations)

Tension Evolution:
  Stage 1 (stat only):       5.9σ vs Planck
  Stage 2 (SH0ES total):     4.0σ
  Stage 3 (parallax):        4.0σ
  Stage 4 (period corr):     1.9σ
  Stage 5 (final):           1.2σ (baseline; 0.3σ to 1.7σ across scenarios)

Multi-Method Convergence:
  JAGB + Cosmic Chronometers: H₀ = 68.22 ± 1.36 km/s/Mpc (Planck-free)
  Three-method (JAGB + H(z) + Planck): H₀ = 67.48 ± 0.50 km/s/Mpc
  Corrected Cepheid residual: ~0.6σ from late-universe mean

================================================================================
IMPORTANT NUMERICAL VALUES FOR VERIFICATION
================================================================================

1. Sensitivity Table Corrections (Lines 426-432)
   - Scenario A + Prior 3: 70.54 km/s/Mpc
   - Scenario B + Prior 2: 68.00 km/s/Mpc (tension 0.3σ)
   - Scenario B + Prior 3: 69.67 km/s/Mpc
   - All values mathematically consistent with R22 baseline (73.04)

2. Figure 4 Caption (Line 705)
   - SH0ES uncertainty: 1.04 km/s/Mpc
   - Consistent with R22 baseline citation

3. Table 1 Systematic Budget
   - Total systematic uncertainty: 1.71 km/s/Mpc (correlated)
   - 9 systematic error sources included
   - Factor 1.6 increase over SH0ES assessment after accounting for correlations

4. JWST Cross-Validation (Figure 3)
   - 15 galaxies with JWST NIRCam measurements
   - Cepheid vs JAGB scatter: 2.3× larger than JAGB vs TRGB
   - Confirms systematic underestimate in Cepheid method

================================================================================
TROUBLESHOOTING
================================================================================

Problem: Compilation errors or missing packages
Solution: Ensure full TeX Live distribution is installed (not BasicTeX)

Problem: Missing figures
Solution: Verify figures/ subdirectory is present with all 14 figure files

Problem: Bibliography not appearing
Solution: Run full compilation sequence (pdflatex → bibtex → pdflatex × 2)

Problem: Symbol rendering issues (σ, μ, etc.)
Solution: Add \usepackage{lmodern} after line 12 in manuscript.tex

================================================================================
CONTACT & CITATION
================================================================================

Author: Aaron Wiley
ORCID: 0009-0007-1612-9203
Email: awiley@outlook.com

Citation:
  Wiley, A. 2025, "Forensic Analysis of Distance Ladder Systematics:
  The Hubble Tension Reduced from ~6σ to ~1σ", ApJ (submitted)

For questions about methodology, data, or analysis, please contact the author.

================================================================================
